import 'package:intl/intl.dart';

class Task {
  String description;
  DateTime dateTime;
  bool isCompleted;
  String category;
  String priority;

  Task({
    required this.description,
    required this.dateTime,
    this.isCompleted = false,
    this.category = 'Work',
    this.priority = 'High',
  });

  Map<String, dynamic> toJson() => {
    'description': description,
    'dateTime': dateTime.toIso8601String(),
    'isCompleted': isCompleted,
    'category': category,
    'priority': priority,
  };

  factory Task.fromJson(Map<String, dynamic> json) {
    return Task(
      description: json['description'],
      dateTime: DateTime.parse(json['dateTime']),
      isCompleted: json['isCompleted'],
      category: json['category'],
      priority: json['priority'],
    );
  }

  String get formattedDate {
    final DateFormat formatter = DateFormat('dd/MM/yy');
    return formatter.format(dateTime);
  }

  String get formattedTime {
    final DateFormat formatter = DateFormat('HH:mm');
    return formatter.format(dateTime);
  }
}
