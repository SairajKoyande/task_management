import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:intl/intl.dart';
import 'package:task_management/model/task.dart';
import 'sign_in_screen.dart';
import 'user_profile_screen.dart';

const Color tdRed = Color(0xFFDA4040);
const Color tdBlue = Color(0xFF5F52EE);
const Color tdBlack = Color(0xFF3A3A3A);
const Color tdGrey = Color(0xFF717171);
const Color tdBGColor = Color(0xFFEEEFF5);

class TaskManagementScreen extends StatefulWidget {
  @override
  _TaskManagementScreenState createState() => _TaskManagementScreenState();
}

class _TaskManagementScreenState extends State<TaskManagementScreen> {
  List<Task> tasks = [];
  List<Task> pendingTasks = [];
  List<Task> completedTasks = [];
  List<Task> filteredTasks = [];
  DateTime _selectedDate = DateTime.now();
  TimeOfDay _selectedTime = TimeOfDay.now();

  @override
  void initState() {
    super.initState();
    _loadTasks();
  }

  void _loadTasks() async {
    final prefs = await SharedPreferences.getInstance();
    final tasksJson = prefs.getStringList('tasks') ?? [];
    setState(() {
      tasks = tasksJson.map((task) => Task.fromJson(Map<String, dynamic>.from(json.decode(task)))).toList();
      filteredTasks = tasks;
      _segregateTasks();
    });
  }

  void _saveTasks() async {
    final prefs = await SharedPreferences.getInstance();
    final tasksJson = tasks.map((task) => json.encode(task.toJson())).toList();
    prefs.setStringList('tasks', tasksJson);
  }

  void _segregateTasks() {
    setState(() {
      pendingTasks = filteredTasks.where((task) => !task.isCompleted).toList();
      completedTasks = filteredTasks.where((task) => task.isCompleted).toList();
    });
  }

  void _addTask(String taskDescription, DateTime dateTime, String category, String priority) {
    if (taskDescription.isNotEmpty) {
      setState(() {
        tasks.add(Task(description: taskDescription, dateTime: dateTime, category: category, priority: priority));
        _segregateTasks();
        _saveTasks();
        _showFeedback('Task added successfully!');
      });
    }
  }

  void _deleteTask(Task task) {
    setState(() {
      tasks.remove(task);
      if (task.isCompleted) {
        completedTasks.remove(task);
      } else {
        pendingTasks.remove(task);
      }
      _saveTasks();
      _segregateTasks();
      _showFeedback('Task deleted successfully!');
    });
  }

  void _toggleTaskCompletion(int index) {
    setState(() {
      final task = tasks[index];
      task.isCompleted = !task.isCompleted;
      _segregateTasks();
      _saveTasks();
    });
  }

  void _logout() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('name');
    await prefs.remove('phone');
    Navigator.of(context).pushReplacement(MaterialPageRoute(
      builder: (context) => SignInScreen(),
    ));
  }

  void _showFeedback(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        duration: Duration(seconds: 2),
      ),
    );
  }

  Future<void> _selectDate(BuildContext context) async {
    DateTime? selectedDate = await showDatePicker(
      context: context,
      initialDate: _selectedDate,
      firstDate: DateTime(_selectedDate.year - 1),
      lastDate: DateTime(_selectedDate.year + 1),
    );
    if (selectedDate != null && selectedDate != _selectedDate) {
      setState(() {
        _selectedDate = selectedDate;
      });
    }
  }

  Future<void> _selectTime(BuildContext context) async {
    TimeOfDay? selectedTime = await showTimePicker(
      context: context,
      initialTime: _selectedTime,
    );
    if (selectedTime != null && selectedTime != _selectedTime) {
      setState(() {
        _selectedTime = selectedTime;
      });
    }
  }

  void _showAddTaskDialog() {
    final descriptionController = TextEditingController();
    String selectedCategory = 'Work';
    String selectedPriority = 'High';
    final categories = ['Work', 'Personal', 'Others'];
    final priorities = ['High', 'Medium', 'Low'];

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Add Task'),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: descriptionController,
                decoration: InputDecoration(labelText: 'Task Description'),
              ),
              SizedBox(height: 16),
              DropdownButtonFormField<String>(
                value: selectedCategory,
                items: categories.map((category) {
                  return DropdownMenuItem<String>(
                    value: category,
                    child: Text(category),
                  );
                }).toList(),
                onChanged: (value) {
                  setState(() {
                    selectedCategory = value!;
                  });
                },
                decoration: InputDecoration(labelText: 'Category'),
              ),
              SizedBox(height: 16),
              DropdownButtonFormField<String>(
                value: selectedPriority,
                items: priorities.map((priority) {
                  return DropdownMenuItem<String>(
                    value: priority,
                    child: Text(priority),
                  );
                }).toList(),
                onChanged: (value) {
                  setState(() {
                    selectedPriority = value!;
                  });
                },
                decoration: InputDecoration(labelText: 'Priority'),
              ),
              SizedBox(height: 16),
              ElevatedButton(
                onPressed: () {
                  _addTask(
                    descriptionController.text,
                    DateTime(
                      _selectedDate.year,
                      _selectedDate.month,
                      _selectedDate.day,
                      _selectedTime.hour,
                      _selectedTime.minute,
                    ),
                    selectedCategory,
                    selectedPriority,
                  );
                  Navigator.of(context).pop();
                },
                child: Text('Add Task', style: TextStyle(color: tdBlue)),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.white,
                  side: BorderSide(color: tdBlue, width: 2),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: tdBGColor,
      appBar: AppBar(
        title: Text('Task Management'),
        backgroundColor: tdBlue,
        foregroundColor: Colors.white,
        actions: [
          IconButton(
            icon: Icon(Icons.person, color: Colors.white),
            onPressed: () {
              Navigator.of(context).push(MaterialPageRoute(
                builder: (context) => UserProfileScreen(),
              ));
            },
          ),
          IconButton(
            icon: Icon(Icons.logout, color: Colors.white),
            onPressed: _logout,
          ),
        ],
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: TextField(
              onChanged: (value) {
                setState(() {
                  filteredTasks = tasks
                      .where((task) => task.description
                      .toLowerCase()
                      .contains(value.toLowerCase()))
                      .toList();
                  _segregateTasks();
                });
              },
              decoration: InputDecoration(
                labelText: 'Search Tasks',
                prefixIcon: Icon(Icons.search, color: tdGrey),
                filled: true,
                fillColor: Colors.white,
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(10),
                ),
              ),
            ),
          ),
          Expanded(
            child: ListView(
              children: [
                _buildTaskList(pendingTasks, 'Pending Tasks', false),
                SizedBox(height: 10),
                _buildTaskList(completedTasks, 'Completed Tasks', true),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    decoration: InputDecoration(
                      labelText: 'Add Task',
                      filled: true,
                      fillColor: Colors.white,
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10),
                      ),
                    ),
                    onSubmitted: (value) => _showAddTaskDialog(),
                  ),
                ),
                SizedBox(width: 10),
                ElevatedButton(
                  onPressed: _showAddTaskDialog,
                  child: Icon(Icons.add, size: 30, color: Colors.white),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: tdBlue,
                    shape: CircleBorder(side: BorderSide(color: tdBlue, width: 2)),
                    padding: EdgeInsets.all(16),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTaskList(List<Task> taskList, String title, bool isCompleted) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
          child: Text(title, style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: tdBlack)),
        ),
        ...taskList.map((task) {
          final index = tasks.indexOf(task);
          return Card(
            elevation: 4,
            margin: EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
            child: ListTile(
              contentPadding: EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
              title: Text(task.description, style: TextStyle(fontSize: 16, color: tdBlack)),
              subtitle: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('${task.formattedDate} ${task.formattedTime}', style: TextStyle(color: tdGrey)),
                  Text('Category: ${task.category}', style: TextStyle(color: tdGrey)),
                  Text('Priority: ${task.priority}', style: TextStyle(color: tdGrey)),
                ],
              ),
              trailing: isCompleted
                  ? IconButton(
                icon: Icon(Icons.delete, color: tdRed),
                onPressed: () => _deleteTask(task),
              )
                  : Checkbox(
                value: task.isCompleted,
                onChanged: (value) => _toggleTaskCompletion(index),
                activeColor: tdBlue,
              ),
            ),
          );
        }).toList(),
      ],
    );
  }
}
